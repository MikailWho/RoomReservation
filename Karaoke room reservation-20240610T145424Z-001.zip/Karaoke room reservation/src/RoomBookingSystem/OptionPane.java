/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package RoomBookingSystem;


/**
 *
 * @author mwhan
 */
public class OptionPane extends javax.swing.JOptionPane{
    /* OVERLOAD */
//    Inheriting From JOptionPane
    public void showMessage(String message){
        showMessageDialog(null, "Reservation Confirmed");
    }
    
    public void showMessage(String message, String title){
        showMessageDialog(null, "Reservation Confirmed", "Karaoke Room Reservation Systems", OK_OPTION);
    }
}
